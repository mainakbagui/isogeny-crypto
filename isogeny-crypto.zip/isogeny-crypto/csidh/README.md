# CSIDH key exchange in pure Python

An implementation of CSIDH (Castryck, Lange, Martindale, Panny, Renes, ASIACRYPT 2018), the commutative supersingular isogeny Diffie–Hellman key exchange, with public-key validation and tests. It needs only Python 3.8 or later.

```
python3 csidh.py           # CSIDH-512 key exchange, about 11 s
python3 csidh.py --toy     # toy parameters, p = 419
python3 test_csidh.py      # brute-force checks at p = 419 (under 1 s); add --512 for CSIDH-512
```

## Mathematics

Let $p = 4\ell_1\cdots\ell_n - 1$ be prime, with $\ell_1,\dots,\ell_n$ distinct odd primes, and let $E_A : y^2 = x^3 + Ax^2 + x$ over $\mathbb{F}_p$. If $E_A$ is supersingular then $\#E_A(\mathbb{F}_p) = p+1$ and the Frobenius $\pi$ satisfies $\pi^2 = -p$. Each $\ell_i$ therefore splits in $\mathcal{O} = \mathbb{Z}[\sqrt{-p}]$ as

$$\ell_i\mathcal{O} = \mathfrak{l}_i\,\overline{\mathfrak{l}}_i, \qquad \mathfrak{l}_i = (\ell_i,\ \pi - 1),\quad \overline{\mathfrak{l}}_i = (\ell_i,\ \pi + 1).$$

The class group $\mathrm{cl}(\mathcal{O})$ acts freely and transitively on the set of $\mathbb{F}_p$-isomorphism classes of supersingular curves with $\mathbb{F}_p$-endomorphism ring $\mathcal{O}$, and each class has a unique Montgomery coefficient $A \in \mathbb{F}_p$. The ideal $\mathfrak{l}_i$ sends $E_A$ to $E_A/\langle K\rangle$, where $K \in E_A(\mathbb{F}_p)$ has order $\ell_i$; $\mathfrak{l}_i^{-1} = \overline{\mathfrak{l}}_i/\ell_i$ uses a point of order $\ell_i$ with $x \in \mathbb{F}_p$ and $y \notin \mathbb{F}_p$, that is, a point of the quadratic twist.

A secret key is $e \in [-m, m]^n$, standing for $[\mathfrak{a}] = [\mathfrak{l}_1^{e_1}\cdots\mathfrak{l}_n^{e_n}]$. The public key is the coefficient of $[\mathfrak{a}]E_0$. Commutativity of $\mathrm{cl}(\mathcal{O})$ gives the shared secret

$$[\mathfrak{a}]\big([\mathfrak{b}]E_0\big) = [\mathfrak{b}]\big([\mathfrak{a}]E_0\big).$$

All arithmetic is $x$-only on $\mathbb{P}^1(\mathbb{F}_p)$, using the Montgomery ladder. For $K$ of odd order $\ell = 2d+1$, with $x_i = x([i]K)$ for $1 \le i \le d$, the isogeny with kernel $\langle K \rangle$ is computed with Vélu's formulas in Montgomery form:

$$\phi(x) = x\prod_{i=1}^{d}\left(\frac{x x_i - 1}{x - x_i}\right)^{2}, \qquad A' = \tau\,(A - 3\sigma), \quad \tau = \prod_{i=1}^{d} x_i^2, \quad \sigma = 2\sum_{i=1}^{d}\Big(x_i - \frac{1}{x_i}\Big).$$

`act` follows Algorithm 2 of the paper. It samples $x \in \mathbb{F}_p$, which gives a point of $E_A$ or of its twist. It then clears the cofactor and walks every $\ell_i$ of the matching sign whose exponent is not yet used up.

`validate` rejects a public key unless $A \neq \pm 2$ and some point $P$ satisfies $[p+1]P = 0$ with order $d \mid p+1$, $d > 4\sqrt{p}$. The Hasse bound then forces $\#E_A(\mathbb{F}_p) = p+1$.

## Parameters

| name | $\ell_i$ | $p$ | $m$ | key space |
|---|---|---|---|---|
| toy | $3, 5, 7$ | $419$ | 2 | $5^3 = 125$ vectors for $h(-4p) = 27$ classes |
| CSIDH-512 | the first 73 odd primes, and 587 | 511 bits | 5 | $11^{74} \approx 2^{256}$ |

The 511-bit prime equals the published CSIDH-512 prime.

## What the tests check

At $p = 419$, `test_csidh.py` checks the following:

1. Every curve reached has $\#E_A(\mathbb{F}_p) = p+1$, by counting points directly.
2. Every computed isogeny maps $E_A(\mathbb{F}_p)$ into $E_{A'}(\mathbb{F}_p)$, and twist points to twist points.
3. The action commutes, and $[\mathfrak{a}^{-1}][\mathfrak{a}]E_0 = E_0$.
4. The orbit of $E_0$ has exactly $h(-4p) = 27$ elements. The class number is computed independently from reduced binary quadratic forms, and the orbit is all 27 supersingular Montgomery coefficients in $\mathbb{F}_{419}$.
5. `validate` agrees with point counting for all 419 values of $A$.

It also runs a CSIDH-512 exchange end to end.

## Limitations

- **Not constant time.** The running time depends on the secret exponents, so the code leaks them through timing. Constant-time variants include Meyer–Campos–Reith (2019), Onuki et al. (2019) and CTIDH (Banegas et al., 2021). This is a reference implementation, not production code.
- **Quantum security.** CSIDH is subject to Kuperberg-type subexponential quantum attacks on the hidden-shift problem. Peikert (2020) and Bonnetain–Schrottenloher (2020) estimate that CSIDH-512 falls short of NIST level 1, so much larger primes are now recommended.
- **The SIDH attacks do not apply.** The 2022 attacks on SIDH/SIKE (Castryck–Decru; Maino–Martindale; Robert) use the auxiliary torsion images that SIDH publishes. CSIDH publishes no such images, so these attacks do not apply to it.

## Related

`../isogeny-graphs/brandt_spectra.sage` studies the full supersingular $\ell$-isogeny graph over $\mathbb{F}_{p^2}$ through Brandt matrices. CSIDH works on the $\mathbb{F}_p$-rational subgraph. There, the $\ell_i$-isogenies form cycles given by the action of $[\mathfrak{l}_i]$, which is a Cayley graph of $\mathrm{cl}(\mathbb{Z}[\sqrt{-p}])$.
