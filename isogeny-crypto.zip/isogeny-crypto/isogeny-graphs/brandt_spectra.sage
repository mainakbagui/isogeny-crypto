# brandt_spectra.sage -- supersingular l-isogeny graphs over F_{p^2} and their Brandt matrices.
# Mainak Bagui. Run on SageMathCell (https://sagecell.sagemath.org) or CoCalc; about 10 s in Sage 10.8.
#
# Row i of B(l) lists the roots of Phi_l(j_i, Y) with multiplicity, i.e. the l-isogeny kernels
# from E_{j_i}; every row sums to l + 1. The script checks, for each (p, l) with l != p:
#  (i)   charpoly B(l) = charpoly of T_l on M_2(Gamma_0(p))       [Deuring, Eichler]
#  (ii)  B(l) W is symmetric, W = diag(|Aut E_j|/2);
#        B(l) itself is symmetric iff p = 1 (mod 12)
#  (iii) every eigenvalue other than l + 1 has |lambda| <= 2 sqrt(l)   [Eichler-Shimura, Weil]

R.<x, y> = ZZ[]

def supersingular_graph(p, l):
    F = GF(p^2, 'a'); S.<Y> = F[]
    Phi = R(str(pari.polmodular(l)))                      # classical modular polynomial
    D = next(D for D in range(-3, -10^6, -1)              # p inert in Q(sqrt D) => roots of H_D are supersingular
             if fundamental_discriminant(D) == D and kronecker(D, p) == -1)
    V = [hilbert_class_polynomial(D).change_ring(F).roots()[0][0]]
    nbrs, k = {}, 0
    while k < len(V):                                     # breadth-first search; the graph is connected
        r = Phi(V[k], Y).roots()
        assert sum(m for _, m in r) == l + 1              # all l-isogenous j lie in F_{p^2}
        nbrs[V[k]] = r
        V += [t for t, _ in r if t not in V]
        k += 1
    B = matrix(ZZ, len(V))
    for i, j in enumerate(V):
        for t, m in nbrs[j]:
            B[i, V.index(t)] += m
    return V, B

def report(p, l):
    V, B = supersingular_graph(p, l)
    chi = B.charpoly()
    assert chi == ModularForms(Gamma0(p), 2).hecke_matrix(l).charpoly()               # (i)
    W = diagonal_matrix([3 if j == 0 else 2 if j == 1728 else 1 for j in V])
    assert (B * W).is_symmetric()                                                     # (ii)
    ev = [r for r, m in chi.roots(AA) for _ in range(m)]; ev.remove(l + 1)
    lam = max([abs(e) for e in ev], default=0)
    assert lam^2 <= 4 * l                                                             # (iii)
    return p, p % 12, l, len(V), B.is_symmetric(), RR(lam).n(16), RR(2 * sqrt(l)).n(16), RR(l + 1 - lam).n(16)

V, B = supersingular_graph(11, 2)
print(V); print(B)                     # [0, 1] (1728 = 1 mod 11);  [0 3] / [2 1];  eigenvalues 3 and -2 = a_2(11a)
print("p  p%12  l  #V  symmetric  max|lambda|  2sqrt(l)  gap")
for p in prime_range(11, 200):
    for l in (2, 3, 5):
        if l != p:
            print(*report(p, l))

# Output (Sage 10.8; same values from the independent PARI/GP check in brandt_check.gp), e.g.
# 11 11 2 2 False 2.000 2.828 1.000
# 37 1 3 3 True 3.000 3.464 1.000
# 97 1 2 8 True 2.802 2.828 0.1981
# 199 7 5 17 False 3.593 4.472 2.407
