\\ brandt_check.gp -- independent PARI/GP check of brandt_spectra.sage (same graph, same three checks).
\\ Usage in gp:  \r brandt_check.gp   then   check(11,2)   -> [p, p%12, l, #V, symmetric?, max|lambda|, 2sqrt(l), gap]
wt(j)=if(j==0,3,if(j==1728,2,1));
rootsF(P)={my(fa=factor(P),R=List()); for(i=1,#fa~, if(poldegree(fa[i,1])==1, my(r=-polcoef(fa[i,1],0)/polcoef(fa[i,1],1)); for(k=1,fa[i,2],listput(R,r)))); Vec(R)};
\\ supersingular l-isogeny graph over F_{p^2} via Phi_l; row i = multiplicities of roots of Phi_l(j_i,Y)
ssgraph(p,l)={
  my(g=ffgen([p,2],'a), D=-3, j0, V=List(), Phi=polmodular(l,,'x,'y), q=1, R, n, B, idx);
  while(!(isfundamental(D) && kronecker(D,p)==-1), D--);
  j0 = rootsF(subst(polclass(D),'x,'y)*g^0)[1];
  listput(V,j0);
  while(q<=#V, R=rootsF(substvec(Phi,['x],[V[q]])*g^0); for(k=1,#R, my(new=1); for(m=1,#V, if(V[m]==R[k], new=0)); if(new, listput(V,R[k]))); q++);
  V=Vec(V); n=#V; B=matrix(n,n);
  for(i=1,n, R=rootsF(substvec(Phi,['x],[V[i]])*g^0); if(#R!=l+1, error("not all roots in F_{p^2}"));
     for(k=1,#R, my(t=0); for(m=1,n, if(V[m]==R[k], t=m)); B[i,t]++));
  [V,B]
};
check(p,l)={
  my(G=ssgraph(p,l), V=G[1], B=G[2], n=#V, W=matdiagonal(apply(wt,V)), mf=mfinit([p,2],1), chiS, chiB, ev, lam);
  chiB=charpoly(B); chiS=charpoly(mfheckemat(mf,l));
  if(chiB != ('x-(l+1))*chiS, error("charpoly mismatch p=",p," l=",l));
  if(B*W != (B*W)~, error("weighted symmetry fails"));
  ev = if(poldegree(chiS)>0, polroots(chiS), []);
  lam = if(#ev, vecmax(apply(z->abs(real(z)),ev)), 0);
  if(lam > 2*sqrt(l)+1e-9, error("Ramanujan fails"));
  [p, p%12, l, n, B==B~, lam, 2*sqrt(l), (l+1)-lam]
};
